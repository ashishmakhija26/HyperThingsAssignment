package com.qa.Login;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.ObjectFactory;




public class LoginCreditionals {

	public static void main(String[] args) throws IOException, InterruptedException {
		System.setProperty("webdriver.chrome.driver", "E:\\Shammi Jha Automation\\Setups\\chromedriver_win32 (3)\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.hyperthings.om/login");
		
	
	// Specify the location of property file
		File src = new File("E:\\Shammi Jha Automation\\eclipse-workspace\\AssigmentHyperthings\\src\\Object_Repo.properties");
		
		//Create FileInputStream class object to load the file
		
		FileInputStream fis= new FileInputStream(src);
		
		//Create the properties class object to read the properties file
		
		Properties pro=new Properties();
		pro.load(fis);
		driver.findElement(By.id("email")).sendKeys(pro.getProperty("username"));
		driver.findElement(By.id("Password")).sendKeys(pro.getProperty("password"));
		driver.findElement(By.xpath("//*[@class='btn yellow btn-radius fullwidth']")).click();		
	
		
		
		Thread.sleep(3000);
			//Alert alert	= driver.switchTo().alert();
	        ////String alertText = alert.getText();
		
		
	    	  TakesScreenshot ts=(TakesScreenshot)driver;
		
			File source=ts.getScreenshotAs(OutputType.FILE);
			
			FileUtils.copyFile(source, new File("./Screenshots/LoginFailure.png"));
		
		}
	

	
		
	}


